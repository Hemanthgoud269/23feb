package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bean.Userbean;
import com.controller.Commonconnection;

public class Createprofiledao {
	Connection c=null;
	PreparedStatement ps=null;
	
	public void addUser(Userbean bean) throws Exception
	{
		 c=Commonconnection.getCon();
		 
		 if(bean.getAgent().equals("Claim Handler")) 
		 {
		ps=c.prepareStatement("insert into userrole values(?,?,?,?)");
		ps.setString(1, bean.getUserName());
        ps.setString(2, bean.getPassWord());
        ps.setString(3, bean.getRoleCode());
        ps.setString(4, null);
        ps.executeUpdate();
        System.out.println("Added one user data into database ");
       
	}
		 else
		 {
			 ps=c.prepareStatement("insert into userrole values(?,?,?,?)");
				ps.setString(1, bean.getUserName());
		        ps.setString(2, bean.getPassWord());
		        ps.setString(3, bean.getRoleCode());
		        ps.setString(4, bean.getAgent());
		        ps.executeUpdate();
		        System.out.println("Added one user data into database ");
		 }
}
}