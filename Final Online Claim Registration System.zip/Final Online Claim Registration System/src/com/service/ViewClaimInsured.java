package com.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ViewClaimInsured extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String num=request.getParameter("username");
		
		
		HttpSession session7=request.getSession(true);
		session7.setAttribute("user", num);
		RequestDispatcher rd=null;
		rd=request.getRequestDispatcher("/viewclaiminsured.jsp");
		rd.forward(request, response);

		
}
}