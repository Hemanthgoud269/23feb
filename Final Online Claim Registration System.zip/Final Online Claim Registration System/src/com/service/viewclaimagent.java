package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.Commonconnection;

public class viewclaimagent extends HttpServlet {
public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

	
	Connection con=null;
	 con=Commonconnection.getCon();
	String s=null;
			String s1=null;
	PreparedStatement ps= null;
		RequestDispatcher rd=null;
		PrintWriter out=res.getWriter();
		String no=req.getParameter("user1");
		ResultSet rs=null;
		HttpSession session5=req.getSession();
		session5.setAttribute("un", no);
		
		HttpSession session9=req.getSession();
		String um=(String)session9.getAttribute("user");
		//System.out.println(um);
		try {
			ps=con.prepareStatement("select agentcode from userrole where username=?");
			ps.setString(1,um);
			rs=ps.executeQuery();
			while(rs.next()) {
				
			s=rs.getString(1);
				
			}
			ps=con.prepareStatement("select agentcode from userrole where username=?");
			ps.setString(1,no);
			rs=ps.executeQuery();
			while(rs.next()) {
				
				s1=rs.getString(1);
				
			}
			if(s.equals(s1)) {
				
				rd=req.getRequestDispatcher("/viewclaim.jsp");
				
				rd.forward(req, res);
				
			}
			else {
				
         rd=req.getRequestDispatcher("/ViewClaimFailAgent.jsp");
				
				rd.forward(req, res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*rd=req.getRequestDispatcher("/viewclaim.jsp");
		//System.out.println("suresh");
		rd.forward(req, res);*/
}
}
