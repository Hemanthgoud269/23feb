package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.*;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login  extends HttpServlet {
	
	Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 c=Commonconnection.getCon();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id=request.getParameter("username");
		//System.out.println(id);
		String password=request.getParameter("password");
		//System.out.println(password);
		HttpSession session2=request.getSession();
		session2.setAttribute("user", id);
		Statement stmt =c.createStatement();
		
		String sql = "select rolecode from userrole WHERE USERNAME = '" + id + "'AND PASSWORD = '" + password + "'";
	
		int i=stmt.executeUpdate(sql);
		System.out.println(i);
		ResultSet rs=stmt.executeQuery(sql);
		
			while(rs.next()) {
				str=rs.getString(1);
				
			}
			if("Claim Adjuster".equals(str)) {
				rd=request.getRequestDispatcher("/Admin.jsp");
				rd.forward(request, response);
				
				
			}
			else if("Claim Handler".equals(str)) {
				rd=request.getRequestDispatcher("/Agent.jsp");
				rd.forward(request, response);
			}
			else if("Insured".equals(str))
			{
				rd=request.getRequestDispatcher("/Insured.jsp");
				rd.forward(request, response);
			}
			else
			{
			
				rd=request.getRequestDispatcher("/Login.jsp");
				rd.forward(request, response);
			}
		} 
		catch (Exception e) {
		
			e.printStackTrace();
		} 
}
}
