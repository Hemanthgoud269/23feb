package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.QueryMapper;

public class Success extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Statement stmt=null;
		Connection con;
		Commonconnection c=new Commonconnection();
		con=c.getCon();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
PrintWriter out=response.getWriter();
HttpSession session =request.getSession(false);
//session.getAttribute("claim");
String str[]=new String[5];
str[0]=request.getParameter("Were you present when the accident happened?");
str[1]=request.getParameter("Was the incident reported to the police station?");
str[2]=request.getParameter("Did you already know something about the problem?");
str[3]=request.getParameter("Were you expecting the problem?");
str[4]=request.getParameter("Did you already have the safety measures?");

String arr[]={"Were you present when the accident happened?",
		"Was the incident reported to the police station?",
		"Did you already know something about the problem?",
		"Were you expecting the problem?",
		"Did you already have the safety measures?"};

HttpSession session12=request.getSession(false);
int i = (int)session12.getAttribute("pn1");
System.out.println("policy number= "+i);


try {
	stmt=con.createStatement();
for(int i1=0;i1<5;i1++)
{
	String s=str[i1];
	System.out.println(arr[i1]);
	 ps=con.prepareStatement("insert into policydetails values("+i+",'"+arr[i1]+"','"+str[i1]+"')");
//String sql="insert into policydetails values("+i+",'"+arr[i1]+"','"+str[i1]+"')";
	ps.executeUpdate();
	
}
}catch (Exception e) {
		
		e.printStackTrace();
	}
	

out.println("Your Claim is Successfully Created With Claim Number:"+session.getAttribute("claim"));
	}
}
